ENIRDE BETTING TIPS - Version 1
This is the first Android source-code prototype.
It includes Home, VIP, Results and Account screens.
Payment, real authentication, backend, notifications and automatic VIP unlocking
are intentionally not connected yet; those require a server/payment provider.

Build with Android Studio using Gradle.
Application ID: com.enirde.bettings
Version: 1.0 (code 1)
