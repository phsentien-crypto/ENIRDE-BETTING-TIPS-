package com.enirde.bettingtips

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11,18,32))
        }
        val title = TextView(this).apply {
            text = "ENIRDE BETTING TIPS"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 18, 22, 18)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 18)
        }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            setPadding(6, 6, 6, 6)
            setBackgroundColor(Color.rgb(18,28,45))
        }
        listOf("Home","VIP","Results","Account").forEach { name ->
            nav.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    when(name) {
                        "Home" -> showHome()
                        "VIP" -> showVip()
                        "Results" -> showResults()
                        "Account" -> showAccount()
                    }
                }
            }, LinearLayout.LayoutParams(0, 58, 1f))
        }
        root.addView(nav)
        return root
    }

    private fun heading(text: String) {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 12, 4, 14)
        })
    }

    private fun card(text: String, locked: Boolean = false) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(25,38,58))
        }
        box.addView(TextView(this).apply {
            this.text = text
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        if (locked) box.addView(TextView(this).apply {
            this.text = "🔒 VIP TIP — Subscribe to unlock"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 0)
        })
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0,0,0,12)
        content.addView(box, p)
    }

    private fun showHome() {
        setContentView(base()); heading("Today's Tips")
        card("⚽ Arsenal vs Chelsea\nPrediction: Over 1.5 Goals\nConfidence: High")
        card("⚽ Barcelona vs Sevilla\nPrediction: Barcelona Win\nConfidence: High")
        card("⭐ Premium Pick\nToday's strongest selection", true)
    }

    private fun showVip() {
        setContentView(base()); heading("VIP Tips")
        card("👑 Daily VIP — Locked\nPremium selections and analysis", true)
        card("🔥 Weekend VIP — Locked\nHigher-odds accumulator", true)
        content.addView(Button(this).apply {
            text = "VIEW SUBSCRIPTION PLANS"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Payment integration will be connected in the next version.", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun showResults() {
        setContentView(base()); heading("Results")
        card("Yesterday\nWon: 7   Lost: 2\nWin rate: 77.8%")
        card("This month\nResults will appear here as you publish them.")
    }

    private fun showAccount() {
        setContentView(base()); heading("Account")
        card("👤 Guest Account\nSign in to access your subscription.")
        content.addView(Button(this).apply {
            text = "LOGIN / SIGN UP"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Account system will be connected in the next version.", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
